package com.pageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.util.Log;

public class OptimusLogin {
	
	
	WebDriver driver;
	
	@FindBy(id="userName")
	WebElement uname;
		 
	 
	@FindBy(id="password")
	WebElement pass;
	
	@FindBy(xpath="//button[@class='ant-btn loginButton ant-btn-primary']")
	WebElement login;

    
  public  OptimusLogin(WebDriver driver) {
	  this.driver = driver;
	  PageFactory.initElements(driver, this);
	}

  
	//Set password in username textbox
    public void setuname(String strUserName){
    	uname.sendKeys(strUserName);
    	Log.info("Username picked from Excel is "+ strUserName);
    	
    }
    
  //Set password in password textbox
    public void setpass(String strPassword){
    	
    	pass.sendKeys(strPassword);
    	Log.info("password picked from Excel is "+ strPassword);
    }
    
    
  //Click on login button
    public void ClickLogin(){
    	login.click();
    	Log.info("Click element found");
    }
    
    
    public void LoginToCore(String strUserName, String strPassword){
    	
    	this.setuname(strUserName);
    	Log.info("Username inserted ");
    	
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	this.setpass(strPassword);
    	Log.info("Username inserted ");
    	
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
    	this.ClickLogin();
    	Log.info("Clicked on Login button ");
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }
    
    
   
    
    
}
