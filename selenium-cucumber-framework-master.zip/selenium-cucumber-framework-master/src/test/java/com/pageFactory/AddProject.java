package com.pageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.util.Log;

public class AddProject {
WebDriver driver;
	
	@FindBy(xpath="//div[@class='ant-card largeBtn ant-card-bordered']")
	WebElement AddProjectButton;
		 
	@FindBy(xpath="//input[@id='title' and @class='ant-input']")
	WebElement EnterProjectName;
	
	@FindBy(xpath="//textarea[@id='description' and @class='ant-input']")
	WebElement EnterProjectDescription;
	
	@FindBy(xpath="//button[@class='ant-btn ant-btn-primary']")
	WebElement CreateProjectButton;
	
	@FindBy(xpath="//button[@class='ant-btn']/span")
	WebElement CancelProjectButton;

	@FindBy(xpath="ant-modal-close-x")
	WebElement CloseSymbol;
	
	@FindBy(xpath="//button[@class='ant-btn largeBtn ant-btn-lg'] ")
	WebElement AddSourceButton;
	
	@FindBy(xpath="//input[@id='title'][@placeholder='Enter Source Name']")
	WebElement EnterSourceName;
	
	@FindBy(xpath="//button[@class='ant-btn ant-btn-primary' and @type='button']")
	WebElement CreateSourceName;
	
	@FindBy(xpath="//span[contains(text(),'Cancel')]")
	WebElement CancelSourceName;
	
	
	public  AddProject(WebDriver driver) {
		  this.driver = driver;
		  PageFactory.initElements(driver, this);
		  
		}
	
	
	public void clickAddProject() throws Exception
	{
		AddProjectButton.click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(3000);
		Log.info("Clicked on add project button ");
	}
	
	public void enterNameDescription(String projectName, String description) throws Exception
	{
		EnterProjectName.sendKeys(projectName);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
		EnterProjectDescription.sendKeys(description);
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Log.info("Entered project Name and Description ");
	}
	
	public void createButtonProject() throws Exception
	{
		CreateProjectButton.click();
		Thread.sleep(5000);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Log.info("Entered project Name and Description ");
	}
	
	public void addSourceButton() throws Exception
	{
		AddSourceButton.click();
		Thread.sleep(1000);
		Log.info("Clicked on Add Source Button ");

	}
	
	public void enterSourceName(String sourceName) throws Exception
	{
		EnterSourceName.sendKeys(sourceName);
		Thread.sleep(2000);
		Log.info("Entered source Name ");

	}
	
	public void createbuttonSource() throws Exception
	{
		CreateSourceName.click();
		Thread.sleep(10000);
		Log.info("Clicked on create button  ");

	}
	}
	    

