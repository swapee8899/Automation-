package com.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;

public class Screenshot {
	static WebDriver driver;
	/*public void screenShot(Scenario scenario) {
	    if (scenario.isFailed()) {
	      // Take a screenshot...
	      final byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	      scenario.embed(screenshot, "image/png"); // ... and embed it in the report.
	    }
	}*/
	public void capture(WebDriver driver,Scenario scenario) throws IOException 
    {
		
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");  
	    Date date = new Date();  
	    String timestamp = formatter.format(date).trim();
	    //System.out.println(timestamp);
		    String ScreenshotPath= "C:/Users/swapnil.wandhe/claimsScreenShot"+timestamp+".png";
		 //File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		    File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(source, new File (ScreenshotPath));
	        System.out.println("Screenshot Taken!!!!");
	       
	        	
			
	        //Thread.sleep(3000);       
                     
     //   return dest;
    }
}
