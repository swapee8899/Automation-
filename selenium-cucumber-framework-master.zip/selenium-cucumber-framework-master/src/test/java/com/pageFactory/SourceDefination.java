package com.pageFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



import com.util.Log;

public class SourceDefination {
WebDriver driver;
	//String fileFormat;
	@FindBy(xpath="//*[@model-id='ebe47332-2e95-46ee-a4a8-b663307e6899']")
	WebElement SorceDefinationImg;
		 
	@FindBy(xpath="//*[@id='title'][@class='ant-select-search__field']")
	WebElement SelectInputFormat;
	
	@FindBy(xpath="//li[contains(text(),'Excel')]")
	WebElement SelectInputList;
	
	@FindBy(xpath="//div[@class='ant-modal-footer']/button[1]")
	WebElement ApplyButton;
	
	@FindBy(xpath="//div[contains(text(),'Layout Definition')]")
	WebElement LayoutDefinitionSection;
	
	@FindBy(xpath="//div[@class='ant-modal-footer']/button[3]")
	WebElement CancelProjectButton;

	@FindBy(xpath="//*[@id='title']/d")
	WebElement ClickDropdown;
	
	/*@FindBy(xpath="//button[@class='ant-btn largeBtn ant-btn-lg'] ")
	WebElement AddSourceButton;
	
	@FindBy(xpath="//input[@id='title'][@placeholder='Enter Source Name']")
	WebElement EnterSourceName;
	
	@FindBy(xpath="//button[@class='ant-btn ant-btn-primary' and @type='button']")
	WebElement CreateSourceName;
	
	@FindBy(xpath="//span[contains(text(),'Cancel')]")
	WebElement CancelSourceName;
	*/
	
	public  SourceDefination(WebDriver driver) {
		  this.driver = driver;
		  PageFactory.initElements(driver, this);
		  
		}
	
	
	public void openSourceFunction() throws Exception
	{
		Actions action = new Actions(driver);
		action.moveToElement(SorceDefinationImg).doubleClick().build().perform();
		
		Thread.sleep(2000);
		Log.info("Clicked on add project button ");
	}
	
	public void inputFormat(String fileFormat) throws Exception
	{
		
		ClickDropdown.click();
		Thread.sleep(1000);
		SelectInputFormat.sendKeys("Excel");
		Thread.sleep(1000);
		Log.info("Clicked on add project button ");
	}
	
	public void clickOnApply() throws Exception
	{
		ApplyButton.click();
		Thread.sleep(3000);
		Log.info("Clicked on add project button ");
	}
	public void layoutDefinitionSection() throws Exception
	{
		LayoutDefinitionSection.click();
		Thread.sleep(3000);
		Log.info("Clicked on add project button ");
	}
	

	}
	    

