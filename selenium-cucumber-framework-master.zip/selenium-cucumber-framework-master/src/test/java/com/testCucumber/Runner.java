package com.testCucumber;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.reporters.Files;

//import com.aventstack.extentreports.gherkin.model.Scenario;
import com.aventstack.extentreports.utils.Reader;
import com.cucumber.listener.Reporter;
import com.util.Screenshot;
import com.util.SendMailSSLWithAttachment;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
 features = "D:\\swpanil\\selenium-cucumber-framework-master\\src\\test\\java\\com\\feature\\Sample.feature"
 ,glue={"stepDefination"},
		// plugin = {"com.cucumber.listener.ExtentCucumberFormatter:output/report.html"},
		 plugin = { "com.cucumber.listener.ExtentCucumberFormatter:Report/Report.html"},
         tags= {"~@smoke"},
		 dryRun = false
 )

public class Runner {
	//static WebDriver driver;

public static void writeExtentReportStart(){
	Reporter.loadXMLConfig(new File("extent-config.xml"));
	
}
	@AfterClass
	public static void writeExtentReport() throws IOException {
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");  
	    Date date = new Date();  
	    String timestamp = formatter.format(date).trim();
	   // System.out.println(timestamp);
		Reporter.setSystemInfo("user", System.getProperty("user.name"));
		Reporter.setSystemInfo("os", "Windows");
		Reporter.setTestRunnerOutput("Sample test runner output message");
		Reporter.addScreenCaptureFromPath("C:/Users/swapnil.wandhe/claimsScreenShot.png");
		//SendMailSSLWithAttachment.Mail();
		
	}
}
