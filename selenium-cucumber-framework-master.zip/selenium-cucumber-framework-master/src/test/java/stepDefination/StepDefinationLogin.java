package stepDefination;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;

import com.pageFactory.AddProject;
import com.pageFactory.Dashboard;
import com.pageFactory.OptimusLogin;
import com.pageFactory.SourceDefination;
import com.util.ExcelReader;
import com.util.Log;
import com.util.Screenshot;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinationLogin 
{
WebDriver driver;
	
    OptimusLogin objLogin;
    Dashboard objDashboard;
	ExcelReader objExcelRead;
	AddProject  objAddProject;
	SourceDefination objSourceDefination;
	
	private String sTestCaseName;

	private int iTestCaseRow;
	Screenshot objscreenshot;
	static Scenario scenarioName;
	//
	@Before 
	public void givenStatement(Scenario scenario)
		{
         this.scenarioName=scenario;
		System.setProperty("webdriver.chrome.driver", "D://chromedriver.exe");
		driver = new ChromeDriver();
		
		Log.info("ChromeDriver initilized ");
		
		
		
		/*driver.get("http://10.11.14.79/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		Log.info("Url Entered ");*/
		}
	
//Scenario Outline: Optimus Login
	
	@Given("^User is on login Page$")
	public void user_is_on_login_Page() {
		
		driver.get("http://10.11.14.84/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Log.startTestCase(scenarioName);
		Log.info("Url Entered ");
		
		String title= driver.getTitle();
		System.out.println(title);
	}
	
	@And("^User enters \"(.*)\" and \"(.*)\" to LogIn$")
	public void LoginToCoreApp(String username, String password)  
		{
			
		objLogin = new OptimusLogin(driver);
		
		objLogin.LoginToCore(username,password);
		
		}
	
	@Then("^User is on home page$")
	public void user_is_on_home_page() throws Exception  {
		String title= driver.getTitle();
		//assertEquals(title,"xyz");
		System.out.println(title);
		Thread.sleep(2000);
	}
	
//Scenario: Optimus Flow Design	
	
	@Given("^User is on dashboard Page$")
	public void user_is_on_dashboard_Page() throws Exception  {
		objDashboard = new Dashboard(driver);
		objDashboard.pageTitleDashboard();
		Log.startTestCase(scenarioName);
	    
	}

	@When("^User clicks on Flow Design$")
	public void user_clicks_on_Flow_Design() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		objDashboard = new Dashboard(driver);
		objDashboard.clickFlowDesign();
	}

	@Then("^User lands on flowDesign page$")
	public void user_lands_on_flowDesign_page() {
		objDashboard = new Dashboard(driver);
		objDashboard.pageTitleFlowDesign();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Then("^User clicks on Add Project Button$")
	public void user_clicks_on_Add_Project_Button() throws Exception {
		objAddProject = new AddProject(driver);
		objAddProject.clickAddProject();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
//WAIT	
	@And("^Wait for \"(.*)\" Seconds$")
	public void Wait_for_time_Seconds(int Time) {
		
		driver.manage().timeouts().implicitlyWait(Time, TimeUnit.SECONDS);
	}
	
//ADD PROJECT	
	@Then("^User Enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_Enters_and(String projectName, String projectDescription) throws Throwable {

		objAddProject = new AddProject(driver);
		objAddProject.enterNameDescription(projectName, projectDescription);
	}

	@And ("^User clicks on create button to create project$")
	public void user_clicks_on_create_button_to_create_project() throws Throwable {

		objAddProject = new AddProject(driver);
		objAddProject.createButtonProject();
	}

//ADD SOURCE
	@When("^User clicks on add source$")
	public void user_clicks_on_add_source() throws Throwable {
		objAddProject = new AddProject(driver);
		objAddProject.addSourceButton();
	}

	@Then("^User enters \"([^\"]*)\"$")
	public void user_enters(String sourceName) throws Throwable {
		objAddProject = new AddProject(driver);
		objAddProject.enterSourceName(sourceName);
	}
	
	@And ("^User clicks on create button to create source$")
	public void User_clicks_on_create_button_to_create_source() throws Throwable {

		objAddProject = new AddProject(driver);
		objAddProject.createbuttonSource();
	}
	
//Source Section 
	

@Then("^User opens source Function$")
public void user_opens_source_Function() throws Throwable {
	objSourceDefination = new SourceDefination(driver);
	objSourceDefination.openSourceFunction();
}

@And("^User select \"([^\"]*)\" from dropdown$")
public void user_select_from_dropdown(String Excel) throws Throwable {
	objSourceDefination = new SourceDefination(driver);
	objSourceDefination.inputFormat(Excel);
}

@And("^User clicks on Apply button$")
public void user_clicks_on_Apply_button() throws Throwable {
	objSourceDefination = new SourceDefination(driver);
	objSourceDefination.clickOnApply();
}

@Then("^User go to layout defination section$")
public void user_go_to_layout_defination_section() throws Throwable {
	objSourceDefination = new SourceDefination(driver);
	objSourceDefination.layoutDefinitionSection();
}


	@After
	public void tearDown(Scenario scenario) throws IOException, Exception
		 {
		if (scenario.isFailed()) {
			System.out.println("isFailed");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Screenshot ss = new Screenshot(); 
		ss.capture(driver, scenario);			
			Log.endTestCase(scenario);
			
			
		 }
		driver.close();
}}