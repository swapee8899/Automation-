package com.pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.util.Log;

public class Dashboard {
WebDriver driver;
	
	@FindBy(xpath="//img[@class='featureIcons' and @alt='FlowDesign']")
	WebElement FlowDesignButton;
		 
	@FindBy(xpath="//button['ant-btn newButton ant-btn-lg']")
	WebElement AddProject;
	
	@FindBy(xpath="//input[@id='title']")
	WebElement ProjectName;
	
	@FindBy(xpath="//textarea[@id='description']")
	WebElement Description;
	
	@FindBy(xpath="//button[@class='ant-btn ant-btn-primary']")
	WebElement CreateButton;

	@FindBy(xpath="//button[@class='ant-btn ant-btn-primary']//preceding::button[1]")
	WebElement CancelButton;
	
	@FindBy(xpath="//span[@class='ant-modal-close-x']")
	WebElement CloseSign;
	
	public  Dashboard(WebDriver driver) {
		  this.driver = driver;
		  PageFactory.initElements(driver, this);
		  
		}
	
	public void pageTitleDashboard() throws Exception
	{
		driver.getTitle();
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		Log.info("Clicked on Flow design button "+driver.getTitle()+" ");
	}
	public void clickFlowDesign() throws Exception
	{
		FlowDesignButton.click();
		Thread.sleep(1000);
		Log.info("Clicked on Flow design button ");
	}
	public void pageTitleFlowDesign()
	{
		driver.getTitle();
		System.out.println(driver.getTitle());
		Log.info("Clicked on Flow design button "+driver.getTitle()+"");
	}
	
	  
}
	    

