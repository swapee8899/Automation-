package enums;

public enum Browser {
	IE,
	Edge,
	Safari,
	Firefox,
	Chrome,
	Opera,
	iPhone5, iPhone5S, iPadMini4, iPadPro, iPadAir, iPad4,
	SamsungGalaxyS5, SamsungGalaxyS4, SamsungGalaxyS3, SamsungGalaxyNote2, SamsungGalaxyNote3, SamsungGalaxyS5Mini, SamsungGalaxyTab410_1, SamsungGalaxyNote10_1, SamsungGalaxyTab3,
	HTCOneM8, HTCOneX,
	MotorolaRazr, MotorolaRazrMaxxHD,
	SonyTipo,
	GoogleNexus5, GoogleNexus4, GoogleNexus7,
	AmazonKindleFire2, AmazonKindleFireHD8_9, AmazonKindleFireHDX7,
	PhantomJS
}
